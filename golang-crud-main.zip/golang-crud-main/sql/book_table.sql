
CREATE TABLE public.book(
    id serial4 NOT NULL,
    "name" varchar NULL,
    CONSTRAINT book_pk PRIMARY KEY (id)
)