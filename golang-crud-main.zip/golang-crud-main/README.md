# Build RestAPI Golang noframework

In this article we will create a rest api in golang without using a framework