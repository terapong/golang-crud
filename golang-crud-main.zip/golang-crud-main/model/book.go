package model

type Book struct {
	Id   int
	Name string
}
